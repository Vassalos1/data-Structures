package Main;

import java.io.IOException;

import FILE.FileManager;
import data.RandomGenerator;
import methods.Methods;

public class Main {
	public static final String methodA = "A";
	public static final String methodB = "B";
	public static final String methodC = "C";

	public Main() {

	}

	static int NUMBER_OF_RECORDS_PER_TEST[] = { 50, 100, 200, 500, 800, 1000, 2000, 5000, 10000, 50000, 100000,
			200000 };

	public static void main(String[] args) throws IOException {
		Methods methods = new Methods();

		System.out.println("METHOD A FOR 59 BYTES PER RECORD");

		for (int i = 0; i < 12; i++) {
			int[] randomInts = RandomGenerator.randomKeysGenerator(NUMBER_OF_RECORDS_PER_TEST[i]);
			methods.methodA(methodA, NUMBER_OF_RECORDS_PER_TEST[i], 59, randomInts);
			methods.initializeSerialSearch(methodA, NUMBER_OF_RECORDS_PER_TEST[i], 59);

			FileManager.closeFile();
		}

		System.out.println(" ");
		System.out.println("METHOD A FOR 31 BYTES PER RECORD");
		for (int i = 0; i < 12; i++) {

			int[] randomInts = RandomGenerator.randomKeysGenerator(NUMBER_OF_RECORDS_PER_TEST[i]);
			methods.methodA(methodA, NUMBER_OF_RECORDS_PER_TEST[i], 31, randomInts);
			methods.initializeSerialSearch(methodA, NUMBER_OF_RECORDS_PER_TEST[i], 31);
			FileManager.closeFile();
		}

		System.out.println(" ");

		System.out.println("METHOD B FOR 59 BYTES PER RECORD");
		for (int i = 0; i < 12; i++) {

			methods.methodB(methodB, NUMBER_OF_RECORDS_PER_TEST[i], 59);
			FileManager.closeFile();
		}

		System.out.println(" ");
		System.out.println("METHOD B FOR 31 BYTES PER RECORD");
		for (int i = 0; i < 12; i++) {

			methods.methodB(methodB, NUMBER_OF_RECORDS_PER_TEST[i], 31);
			FileManager.closeFile();

		}
		System.out.println(" ");
		System.out.println("METHOD C FOR 59 BYTES PER RECORD");
		for (int i = 0; i < 12; i++) {

			methods.methodC(methodC, NUMBER_OF_RECORDS_PER_TEST[i], 59);
			FileManager.closeFile();

		}
		System.out.println(" ");
		System.out.println("METHOD C FOR 31 BYTES PER RECORD");
		for (int i = 0; i < 12; i++) {

			methods.methodC(methodC, NUMBER_OF_RECORDS_PER_TEST[i], 31);
			FileManager.closeFile();

		}
	}
}

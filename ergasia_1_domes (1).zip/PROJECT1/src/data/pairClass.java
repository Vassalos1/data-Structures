package data;

import java.nio.ByteBuffer;

public class pairClass {
	static final int pageSize = 256;
	static final int keySize = 4;

	private int key;
	private int DataPagePos;

	public pairClass(int key, int DataPagePos) {
		this.key = key;
		this.DataPagePos = DataPagePos;
	}

	public pairClass() {

	}

	public static byte[] PairToByteArray(pairClass pair) {

		java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocate(8);
		bb.putInt(pair.key);
		bb.putInt(4, pair.DataPagePos);
		byte byteArray[] = bb.array();
		return byteArray;
	}

	public static pairClass ByteArrayToPairClass(byte[] byteArray) {

		ByteBuffer bb = ByteBuffer.wrap(byteArray);
		int key = bb.getInt();
		int DataPagePos = bb.getInt(4);
		return new pairClass(key, DataPagePos);
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public int getDataPagePos() {
		return DataPagePos;
	}

	public void setDataPagePos(int dataPagePos) {
		DataPagePos = dataPagePos;
	}

}

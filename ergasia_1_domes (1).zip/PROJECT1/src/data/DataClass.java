package data;

import java.nio.ByteBuffer;

public class DataClass {
	/**
	 * 
	 */

	int key;
	String data;
	int PageNum;

	public DataClass(int key, String data) {
		this.data = data;
		this.key = key;
	}

	public DataClass() {

	}

	public static byte[] DataclassToByteArray(DataClass dataclass, int recSize) {

		java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocate(recSize);
		bb.putInt(dataclass.key);
		bb.put(dataclass.data.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
		byte byteArray[] = bb.array();
		return byteArray;
	}

	public static DataClass ByteArrayToDataClass(byte[] byteArray, int dataSize) {

		ByteBuffer bb = ByteBuffer.wrap(byteArray);
		int someInt = bb.getInt();
		byte ba[] = new byte[dataSize];
		bb.get(ba, 0, dataSize);
		String someString = new String(ba, java.nio.charset.StandardCharsets.US_ASCII);
		return new DataClass(someInt, someString);
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public int getPageNum() {
		return PageNum;
	}

	public void setPageNum(int pageNum) {
		PageNum = pageNum;
	}
}

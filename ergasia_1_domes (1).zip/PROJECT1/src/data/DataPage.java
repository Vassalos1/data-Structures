package data;



import FILE.FileManager;

public class DataPage {

	static final int pageSize = 256;
	static final int keySize = 4;
	
	private static int i = 0;
	private static int k = 0;
	// static FileManager fileManager;
	
	public static java.nio.ByteBuffer WriteDataPageBuffer = java.nio.ByteBuffer.allocate(pageSize);

	public DataPage() {

	}

	public static void addToPage(byte[] array, int recSize, FileManager FM) {

		WriteDataPageBuffer.put(array);
		i++;

		if (recSize == 59) {

			if (i == 4) {
				while(WriteDataPageBuffer.hasRemaining()) {
					WriteDataPageBuffer.put((byte)1);
				}
				//WriteDataPageBuffer.put(test);

				FM.writeFile(WriteDataPageBuffer.array());
				// FileManager.diskAccessTotal++;
				i = 0;
				
				WriteDataPageBuffer.clear();
			}
		} else if (recSize == 31) {
			if (i == 8) {
				while(WriteDataPageBuffer.hasRemaining()) {
					WriteDataPageBuffer.put((byte)1);
				}
				//WriteDataPageBuffer.put(test2);

				FM.writeFile(WriteDataPageBuffer.array());
				// FileManager.diskAccessTotal++;
				i = 0;

				WriteDataPageBuffer.clear();
			}
		}
	}

	public static void addToLastPage(byte[] array, int recSize, FileManager FM) {

		if (recSize == 59) {
			WriteDataPageBuffer.put(array);
			i++;
			if (i == 2) {
				while(WriteDataPageBuffer.hasRemaining()) {
					WriteDataPageBuffer.put((byte)1);
				}
				//for (int j = 0; j < 6; j++) {
				//	WriteDataPageBuffer.put(test);
				//}

			//	WriteDataPageBuffer.put(test1);
				FM.writeFile(WriteDataPageBuffer.array());
				// FileManager.diskAccessTotal++;
				i = 0;

				WriteDataPageBuffer.clear();

			}
		} else if (recSize == 31) {
			i = 0;
			WriteDataPageBuffer.put(array);
			i++;
			if (i == 1) {
				while(WriteDataPageBuffer.hasRemaining()) {
					WriteDataPageBuffer.put((byte)1);
				}

				FM.writeFile(WriteDataPageBuffer.array());
				// FileManager.diskAccessTotal++;
				i = 0;
				WriteDataPageBuffer.clear();

			}
		}
	}

	public static void addPairToPage(byte[] array, FileManager FM) {

		WriteDataPageBuffer.put(array);
		k++;
		if (k == 32) {

			FM.writeFile(WriteDataPageBuffer.array());
			// FileManager.diskAccessTotal++;
			k = 0;

			WriteDataPageBuffer.clear();

		}

	}

	public static void addPairToLastPage(byte[] array, FileManager FM, boolean LastPair) {

		WriteDataPageBuffer.put(array);
		k++;
		if (LastPair == true) {
			while(WriteDataPageBuffer.hasRemaining()) {
				WriteDataPageBuffer.put((byte)1);
			}

			FM.writeFile(WriteDataPageBuffer.array());
			// FileManager.diskAccessTotal++;
			k = 0;
			WriteDataPageBuffer.clear();
		}

	}

}

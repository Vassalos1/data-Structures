package data;

public class RandomGenerator {

	// Java program generate a random AlphaNumeric String
	// using Math.random() method

	public RandomGenerator() {

	}

	// function to generate a random string of length n
	public static String getAlphaNumericString(int n) {

		// choose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	public int[] randomGenerator(int recAmount, int length) {
		int[] randomInts;

		if (recAmount <= 1000) {
			java.util.Random randomGenerator = new java.util.Random();
			randomInts = randomGenerator.ints(1, 2 * recAmount).distinct().limit(length).toArray();
		} else {
			java.util.Random randomGenerator = new java.util.Random();
			randomInts = randomGenerator.ints(1, 2 * recAmount).limit(length).toArray();

		}
		return randomInts;

	}

	public static int[] randomKeysGenerator(int recAmount) {

		int[] randomInts;

		java.util.Random randomGenerator = new java.util.Random();
		randomInts = randomGenerator.ints(1, 2 * recAmount).distinct().limit(recAmount).toArray();

		return randomInts;

	}
}

package arraySearch;


import java.io.IOException;
import java.io.RandomAccessFile;


import FILE.FileManager;
import data.DataClass;
import data.pairClass;


public class ArraySearch {
	private static final int PAGE_SIZE = 256;
	public static int counter = 0;

	public static void searchDataClass(String filename, int randomInt, int recSize) throws IOException {

		try (RandomAccessFile fis = new RandomAccessFile(filename, "rw")) {
			byte[] buffer = new byte[PAGE_SIZE];
			int bytesRead;

			while ((bytesRead = fis.read(buffer)) != -1) {
				FileManager.diskAccessTotal++;
				for (int i = 0; i < bytesRead - recSize; i += recSize) {

					byte[] recordBytes = new byte[recSize];

					System.arraycopy(buffer, i, recordBytes, 0, recSize);

						DataClass data = new DataClass();

						data = DataClass.ByteArrayToDataClass(recordBytes, recSize - 4);

						if (data.getKey() == randomInt) {
							
							return;

						}
				}
			}
		}
	}

	public static void searchPairClass(String filename, int randomInt, int recSize) throws IOException {
		try (RandomAccessFile fis = new RandomAccessFile(filename, "rw")) {
			byte[] buffer = new byte[PAGE_SIZE];
			int bytesRead;

			while ((bytesRead = fis.read(buffer)) != -1) {
				FileManager.diskAccessTotal++;
				for (int i = 0; i < bytesRead - 8; i += 8) {

					byte[] recordBytes = new byte[8];

					System.arraycopy(buffer, i, recordBytes, 0, 8);

					for (int j = 0; j < PAGE_SIZE / 8 - 1; j++) {

						pairClass pair = new pairClass();

						pair = pairClass.ByteArrayToPairClass(recordBytes);

						if (pair.getKey() == randomInt) {
									FileManager.diskAccessTotal++;
									return;
						}
					}
				}
			}
		}
	}

	public static void searchInPage(String fileName, int PageNum, int key, int recSize) throws IOException {

		try (RandomAccessFile fis = new RandomAccessFile(fileName, "rw")) {
			byte[] buffer = new byte[PAGE_SIZE];

			fis.seek(PageNum * 256);
			fis.read(buffer);
			FileManager.diskAccessTotal++;
			for (int i = 0; i < 256 - recSize; i += recSize) {

				byte[] recordBytes = new byte[recSize];

				System.arraycopy(buffer, i, recordBytes, 0, recSize);

				DataClass data = new DataClass();

				data = DataClass.ByteArrayToDataClass(recordBytes, recSize - 4);

				if (data.getKey() == key) {

					return;

				}

			}

		}

	}

}

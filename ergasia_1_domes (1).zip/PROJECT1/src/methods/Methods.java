package methods;

import java.io.IOException;

import java.util.Arrays;

import FILE.FileManager;
import arraySearch.ArraySearch;
import binarySearch.BinarySearch;
import data.DataClass;
import data.DataPage;
import data.RandomGenerator;
import data.pairClass;


public class Methods {

	
	static final int pageSize = 256;
	static final int keySize = 4;

	public static final String methodA = "A";
	public static final String methodB = "B";
	public static final String methodC = "C";
	private static final int serialSearchTotal = 1000;
	static DataClass[] dataClass = null;
	static pairClass[] pair = null;
	static int[] keys = null;

	FileManager fileManager;

	public Methods() {

	}

	public void methodA(String fileName, int recAmount, int recSize, int[] randomInts) throws IOException {
		fileManager = new FileManager();
		String alphaNumericString;

		float recPerPage = pageSize / recSize;

		float pageTotal = recAmount / recPerPage;

		fileManager.createFile(fileName);
		dataClass = new DataClass[recAmount];

		for (int i = 0; i < recAmount; i++) {
			alphaNumericString = RandomGenerator.getAlphaNumericString(recSize - keySize);
			dataClass[i] = new DataClass(randomInts[i], alphaNumericString);

			if (recSize == 59) {
				if (pageTotal != (float) Math.round(pageTotal) && (i == recAmount - 2 || i == recAmount - 1)) {

					DataPage.addToLastPage(DataClass.DataclassToByteArray(dataClass[i], recSize), recSize,
							fileManager);

				} else {

					DataPage.addToPage(DataClass.DataclassToByteArray(dataClass[i], recSize), recSize, fileManager);
				}

			} else if (recSize == 31) {
				if (pageTotal != (float) Math.round(pageTotal) && (i == recAmount - 1)) {

					DataPage.addToLastPage(DataClass.DataclassToByteArray(dataClass[i], recSize), recSize,
							fileManager);

				} else {
					DataPage.addToPage(DataClass.DataclassToByteArray(dataClass[i], recSize), recSize, fileManager);

				}
				dataClass[i].setPageNum(FileManager.pageCount);
			}
		}

		if (fileName != "A") {
			FileManager.closeFile();
		}
	}

	public void initializeSerialSearch(String fileName, int recAmount, int recSize) throws IOException {

		int[] randomInts;
		long totalTestStartTimeNano, totalTestEndTimeNano;
		long totalTimeNano = 0;

		java.util.Random randomGenerator = new java.util.Random();
		if (recAmount < 1000) {
			randomInts = randomGenerator.ints(1, 2 * recAmount).limit(serialSearchTotal).toArray();
		} else {
			randomInts = randomGenerator.ints(1, 2 * recAmount).distinct().limit(serialSearchTotal).toArray();
		}
		for (int i = 0; i < serialSearchTotal; i++) {

			totalTestStartTimeNano = System.nanoTime();

			ArraySearch.searchDataClass(fileName, randomInts[i], recSize);

			totalTestEndTimeNano = System.nanoTime();

			totalTimeNano += (totalTestEndTimeNano - totalTestStartTimeNano);

		}

		float MeanTotal = (float) FileManager.diskAccessTotal / serialSearchTotal;

		System.out.println("Mean disk accesses per search : "  +String.format("%.1f",(MeanTotal)) + " and mean time per search is : "
				+ totalTimeNano / serialSearchTotal + "ns for " + recAmount + " records");

		FileManager.diskAccessTotal = 0;
	}

	public void methodB(String fileName, int recAmount, int recSize) throws IOException {
		fileManager = new FileManager();
		int[] randomInts = RandomGenerator.randomKeysGenerator(recAmount);
		float PairPerPage = pageSize / 8;

		float pageTotal = recAmount / PairPerPage;
		methodA(fileName, recAmount, recSize, randomInts);

		fileManager.createFile("B.1");

		// System.out.println(FileManager.diskAccessTotal);
		for (int i = 0; i < recAmount; i++) {
			pairClass pair = new pairClass(dataClass[i].getKey(), dataClass[i].getPageNum());

			if (pageTotal != (float) Math.round(pageTotal) && FileManager.pageCount == (int) pageTotal) {
				if (i == recAmount - 1) {
					DataPage.addPairToLastPage(pairClass.PairToByteArray(pair), fileManager, true);
				} else
					DataPage.addPairToLastPage(pairClass.PairToByteArray(pair), fileManager, false);
			} else {
				DataPage.addPairToPage(pairClass.PairToByteArray(pair), fileManager);
			}
		}

		initializeSerialSearchB("B.1", recAmount, recSize);
	}

	public void initializeSerialSearchB(String fileName, int recAmount, int recSize) throws IOException {

		int[] randomInts;
		long totalTestStartTimeNano, totalTestEndTimeNano;
		long totalTimeNano = 0;

		java.util.Random randomGenerator = new java.util.Random();
		if (recAmount < 1000) {
			randomInts = randomGenerator.ints(1, 2 * recAmount).limit(serialSearchTotal).toArray();
		} else {
			randomInts = randomGenerator.ints(1, 2 * recAmount).distinct().limit(serialSearchTotal).toArray();
		}
		for (int i = 0; i < serialSearchTotal; i++) {

			totalTestStartTimeNano = System.nanoTime();

			ArraySearch.searchPairClass(fileName, randomInts[i], recSize);

			totalTestEndTimeNano = System.nanoTime();

			totalTimeNano += (totalTestEndTimeNano - totalTestStartTimeNano);

		}
		float MeanTotal = (float) FileManager.diskAccessTotal / serialSearchTotal;

		System.out.println("Mean disk accesses per search : " + String.format("%.1f",(MeanTotal)) + " and mean time per search is : "
				+ totalTimeNano / serialSearchTotal + "ns for " + recAmount + " records");

		FileManager.diskAccessTotal = 0;
	}

	public void methodC(String fileName, int recAmount, int recSize) throws IOException {
		fileManager = new FileManager();
		int[] randomInts = RandomGenerator.randomKeysGenerator(recAmount);
		float PairPerPage = pageSize / 8;

		float pageTotal = recAmount / PairPerPage;
		methodA(fileName, recAmount, recSize, randomInts);

		fileManager.createFile("C.1");

		pair = new pairClass[recAmount];
		keys = new int[recAmount];
		for (int i = 0; i < recAmount; i++) {
			pair[i] = new pairClass(dataClass[i].getKey(), dataClass[i].getPageNum());
			keys[i] = pair[i].getKey();

		}

		Arrays.sort(keys);

		for (int i = 0; i < recAmount; i++) {

			for (int j = 0; j < recAmount; j++) {
				if (keys[i] == pair[j].getKey()) {
					pair[j].setKey(keys[i]);

					if (pageTotal != (float) Math.round(pageTotal) && FileManager.pageCount == (int) pageTotal) {

						if (i == recAmount - 1) {
							DataPage.addPairToLastPage(pairClass.PairToByteArray(pair[j]), fileManager, true);

						} else
							DataPage.addPairToLastPage(pairClass.PairToByteArray(pair[j]), fileManager, false);
					} else {
						DataPage.addPairToPage(pairClass.PairToByteArray(pair[j]), fileManager);
					}
					break;
				}

			}
		}
		initializeBinarySearch("C.1", recAmount, recSize);

	}

	public void initializeBinarySearch(String fileName, int recAmount, int recSize) throws IOException {
		float PairPerPage = pageSize / 8;

		float pageTotal = recAmount / PairPerPage;
		int[] randomInts;
		long totalTestStartTimeNano, totalTestEndTimeNano;
		long totalTimeNano = 0;

		java.util.Random randomGenerator = new java.util.Random();
		if (recAmount < 1000) {
			randomInts = randomGenerator.ints(1, 2 * recAmount).limit(serialSearchTotal).toArray();
		} else {
			randomInts = randomGenerator.ints(1, 2 * recAmount).distinct().limit(serialSearchTotal).toArray();
		}
		for (int i = 0; i < serialSearchTotal; i++) {

			totalTestStartTimeNano = System.nanoTime();

			int j = BinarySearch.binarySearch(fileName, 0, (int) pageTotal+1, randomInts[i]);
			totalTestEndTimeNano = System.nanoTime();

			totalTimeNano += (totalTestEndTimeNano - totalTestStartTimeNano);

			if (j != -1) {

				ArraySearch.searchInPage(fileName, j, randomInts[i], recSize);

			}

			
		}
		float MeanTotal = (float) FileManager.diskAccessTotal / serialSearchTotal;

		System.out.println("Mean disk accesses per search : " + String.format("%.1f",(MeanTotal)) + " and mean time per search is : "
				+ totalTimeNano / serialSearchTotal + "ns for " + recAmount + " records");

		FileManager.diskAccessTotal = 0;

	}

}

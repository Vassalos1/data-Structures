package binarySearch;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import FILE.FileManager;

public class BinarySearch {
	private static final int PAGE_SIZE = 256;
	private static final int PAIR_SIZE = 8;

	public BinarySearch(String fileName) throws FileNotFoundException {

	}

	public static int binarySearch(String fileName, int start, int end, int key) throws IOException {

		int pairsPerPage = PAGE_SIZE / PAIR_SIZE;
		if (end >= start) {
			int middle = start + (end - start) / 2;

			RandomAccessFile file = new RandomAccessFile(fileName, "r");

			int pageOffset = middle % pairsPerPage;
			long pageStart = middle * PAGE_SIZE;
			FileManager.diskAccessTotal++;
			file.seek(pageStart);

			for (int i = 0; i < pageOffset; i++) {
				file.skipBytes(PAIR_SIZE);
			}

			int result = -1;
			try {
				int currentKey = file.readInt();
				if (currentKey == key) {
					result = file.readInt();

				} else if (currentKey > key) {
					result = binarySearch(fileName, start, middle - 1, key);
				} else {
					result = binarySearch(fileName, middle + 1, end, key);
				}
			} catch (Exception EOFException) {

			}

			file.close();

			return result;
		} else {
			return -1;

		}

	}
}

package FILE;


import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;




public class FileManager {

	static final int pageSize = 256;
	static final int keySize = 4;
	static final int recSize1 = 59;
	static final int recSize2 = 31;

	public static int pageCount = 0;

	public FileManager() {

	}

	static byte[] buffer = new byte[pageSize];

	public static RandomAccessFile raf;
	public static int diskAccessTotal;

	public void createFile(String fileName) {
		try {

			raf = new RandomAccessFile(fileName, "rw");

			raf.setLength(0);

		} catch (IOException e) {

			System.out.println("Error. I/O exception.");

		}

	}

	public void writeFile(byte[] byteArray) {

		try {

			raf.seek(pageCount * 256);
			pageCount++;

			raf.write(byteArray);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readFile() {

		try {
			raf.read(buffer);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public int openFile(String fileName) {

		int pageTotal;

		File f = new File(fileName);

		if (!f.isFile()) {
			System.out.println("Error. No file exists.");
			return 0;
		}

		try {
			raf = new RandomAccessFile(fileName, "rw");

			pageTotal = (((int) raf.length()) / pageSize) - 1;

		} catch (IOException e) {
			System.out.println("Error. I/O exception.");
			return 0;
		}

		System.out.println("File opened.");

		return pageTotal;
	}

	public static int readRecord(int page) {

		try {
			raf.seek(page * pageSize);

			raf.read(buffer);
		} catch (IOException e) {

			e.printStackTrace();
			return 0;
		}

		return 1;
	}

	public int[] keySelection(int recAmount) {
		int[] randomInts;

		if (recAmount <= 1000) {
			java.util.Random randomGenerator = new java.util.Random();
			randomInts = randomGenerator.ints(1, 2 * recAmount).distinct().limit(recAmount).toArray();
		} else {
			java.util.Random randomGenerator = new java.util.Random();
			randomInts = randomGenerator.ints(1, 2 * recAmount).limit(recAmount).toArray();
		}

		return randomInts;

	}

	public static int closeFile() {

		try {
			pageCount = 0;
			raf.setLength(0);
			raf.close();

		} catch (IOException e) {
			System.out.println("Error. No file exists or no file is opened.");
			return 0;
		}

		// System.out.println("File closed.");

		return 1;
	}

	public static int closeFile1() {

		try {

			raf.close();

		} catch (IOException e) {
			System.out.println("Error. No file exists or no file is opened.");
			return 0;
		}

		// System.out.println("File closed.");

		return 1;
	}

}

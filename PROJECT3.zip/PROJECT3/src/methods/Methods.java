package methods;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import BPlusTree.BTree;
import BPlusTree.BTreeInnerNode;
import BPlusTree.BTreeLeafNode;
public class Methods {
	static BTree<String,LinkedList<FileInfo>> BplusTree = new BTree<String,LinkedList<FileInfo>>();
	 static Scanner scanner = new Scanner(System.in);
	 static boolean tryAgain=true;
	 public static void printMenu() {
			while(tryAgain) {	
				System.out.println("OPERATIONS");
				System.out.println("1.Insert a file on the tree.");
				System.out.println("2.Find the file and the position a word is in.");
				System.out.println("3.Make 100 searches for words that are in the files.");
				System.out.println("4.Exit.");
				System.out.println("Please insert the number of the operation you want to make:");
				
				 Scanner scanner = new Scanner(System.in);
				
				 int userInput = scanner.nextInt();
				switch(userInput) {
					case 1:
						BTreeLeafNode.LEAFORDER=10;
						BTreeInnerNode.INNERORDER=10;
						Methods.insertOnTree();
					
						break;
					
					case 2:
						Methods.searchOnTree();
						break;
						
					case 3:
						BPlusTree.BTree.numberOfAccesses=0;
						 BTreeLeafNode.numberOfCompares=0;
						 
						BTreeLeafNode.LEAFORDER=10;
						BTreeInnerNode.INNERORDER=10;
						
						Methods.AHundredsearches();
						
						BPlusTree.BTree.numberOfAccesses=0;
						 BTreeLeafNode.numberOfCompares=0;
						 
						 BTreeInnerNode.INNERORDER=20;
						 BTreeLeafNode.LEAFORDER=20;
						 
						 Methods.AHundredsearches();
						break;
						
					case 4://end
						System.out.println("Exited");
						tryAgain=false;
						break;
					default:
						System.out.println("This is not a number of an existing operation, please try again.");
						
				}
				
				}
	 }
	 
	public static void insertOnTree() {
		String fileName1 = "1.txt";
		String fileName2 = "2.txt";

		
		System.out.println("Please insert the name of the file you want to insert.");
		 String userInput1 = scanner.nextLine();
		
		 if ((!userInput1.equals(fileName1))   && (!userInput1.equals(fileName2))) {
			 System.out.println("The file you are trying to insert doesn't exist.");
		 } else if (userInput1.equals(fileName1) || userInput1.equals(fileName2)){
			 String fileName = userInput1; 

		        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
		            String line;
		            int position = 0;
		            while ((line = reader.readLine()) != null) {
		                String[] words = line.split(" ");
		                for (String word : words) {
		                    if (BplusTree.search(word)!=null) {
		                        LinkedList<FileInfo> fileList = BplusTree.search(word);
		                        fileList.add(new FileInfo(fileName, position));
		                    } else {
		                        LinkedList<FileInfo> fileList = new LinkedList<>();
		                        fileList.add(new FileInfo(fileName, position));
		                        BplusTree.insert(word,fileList);
		                    }
		                    position++;
		                }
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		         BPlusTree.BTree.numberOfAccesses=0;
				 BTreeLeafNode.numberOfCompares=0;
	}
}
	
	public static void searchOnTree() {
		BPlusTree.BTree.numberOfAccesses=0;
	 	BTreeLeafNode.numberOfCompares=0;
		System.out.println("Please insert the word you want to search.");
		 String word = scanner.nextLine();
		 try {
		        List<FileInfo> searchResults = BplusTree.search(word);
		      
		            for (FileInfo fileInfo : searchResults) {
		                String fileName = fileInfo.getFileName();
		                int position = fileInfo.getPosition();
		                System.out.println("File Name: " + fileName);
		                System.out.println("Position: " + position);
		                System.out.println("----------------------");
		        }
		            System.out.println("The number of accesses for this search is : "+BTree.numberOfAccesses);
		            System.out.println("The number of compares for this search is : "+ BTreeLeafNode.numberOfCompares);
		    } catch (NullPointerException e) {
		        System.out.println("The word you are trying to find doesn't exist in the files.Please try again.");
		    }
		 
		 
		 	
	}
	
	public static void AHundredsearches() {
		 BTree<String,LinkedList<FileInfo>> BplusTree1 = new BTree<String,LinkedList<FileInfo>>();

		
		  try (BufferedReader reader = new BufferedReader(new FileReader("1.txt"))) {
	            String line;
	            int position = 0;
	            while ((line = reader.readLine()) != null) {
	                String[] words = line.split(" ");
	                for (String word : words) {
	                    if (BplusTree1.search(word)!=null) {
	                    	
	           			 //BTree.numberOfAccesses++;

	                        LinkedList<FileInfo> fileList = BplusTree1.search(word);
	                        fileList.add(new FileInfo("1.txt", position));
	                    } else {
	                        LinkedList<FileInfo> fileList = new LinkedList<>();
	                        fileList.add(new FileInfo("1.txt", position));
	                        BplusTree1.insert(word,fileList);
	                    }
	                    position++;
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        // BPlusTree.BTree.numberOfAccesses=0;
			 BTreeLeafNode.numberOfCompares=0;

			 
			 try (BufferedReader reader = new BufferedReader(new FileReader("2.txt"))) {
		            String line;
		            int position = 0;
		            while ((line = reader.readLine()) != null) {
		                String[] words = line.split(" ");
		                for (String word : words) {
		                    if (BplusTree1.search(word)!=null) {

		                        LinkedList<FileInfo> fileList = BplusTree1.search(word);
		                        fileList.add(new FileInfo("2.txt", position));
		                    } else {
		                        LinkedList<FileInfo> fileList = new LinkedList<>();
		                        fileList.add(new FileInfo("2.txt", position));
		                        BplusTree1.insert(word,fileList);
		                    }
		                    position++;
		                }
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		         BPlusTree.BTree.numberOfAccesses=0;
				 BTreeLeafNode.numberOfCompares=0;

		
		
		 List<String> words1 = new ArrayList<>();
		 List<String> words2 = new ArrayList<>();
		 
	        try (BufferedReader reader1 = new BufferedReader(new FileReader("1.txt"))) {
	            String line;
	            while ((line = reader1.readLine()) != null) {
	                String[] lineWords = line.split(" ");
	                for (String word : lineWords) {
	                    words1.add(word);
	                }
	            }
	        } catch (IOException e1) {
	            e1.printStackTrace();
	        }
	        try (BufferedReader reader = new BufferedReader(new FileReader("2.txt"))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] lineWords = line.split(" ");
	                for (String word : lineWords) {
	                    words2.add(word);
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	        Random random = new Random();
	        List<String> randomWords = new ArrayList<>();

	        int wordsToSelect = 50;
	        int totalWords1 = words1.size();

	        for (int i = 0; i < wordsToSelect; i++) {
	            int randomIndex1 = random.nextInt(totalWords1);
	            String randomWord1 = words1.get(randomIndex1);
	            randomWords.add(randomWord1);
	        }
	        int totalWords2 = words2.size();

	        for (int i = 0; i < wordsToSelect; i++) {
	            int randomIndex2 = random.nextInt(totalWords2);
	            String randomWord2 = words1.get(randomIndex2);
	            randomWords.add(randomWord2);
	        }
	      
	        for (String word : randomWords) {
	 
	        	BplusTree1.search(word);
	        }
	       
	        System.out.println("The mean number of accesses for order "+ BTreeLeafNode.LEAFORDER+" is : " +(float)BPlusTree.BTree.numberOfAccesses/100);
			 System.out.println("The mean number of compares for order "+ BTreeLeafNode.LEAFORDER+" is : " + (float)BTreeLeafNode.numberOfCompares/100);
			 
			 BPlusTree.BTree.numberOfAccesses=0;
			 BTreeLeafNode.numberOfCompares=0;
			

	    }
	
		
	}


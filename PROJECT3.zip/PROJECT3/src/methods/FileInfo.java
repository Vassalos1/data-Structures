package methods;

public class FileInfo {
    private String fileName;
    private int position;

    public FileInfo(String fileName, int position) {
        this.fileName = fileName;
        this.position = position;
    }

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}


}
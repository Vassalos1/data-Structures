package main;

import methods.Methods;
public class Main {

	
	public static void main(String[] args) {
		Methods.printMenu();
	}
}

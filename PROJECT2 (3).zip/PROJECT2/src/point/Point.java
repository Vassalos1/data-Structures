package point;

public class Point {
	private int x;
	private int y;
	
	public Point(int x,int y) {
		
		this.x=x;
		this.y=y;
	}
	public int[] getPoint(int x,int y) {
		int[] point= new int[2];
		
		point[0]=x;
		point[1]=y;
		return point;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	
}

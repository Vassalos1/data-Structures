package methods;


import trees.KDTree;
import trees.PRQuadTree;
import node.Node;


public class methods {
	private final int N=262144;
	private final int numOfSearches=100;
	 static KDTree KDtree;
	 static PRQuadTree QuadTree;
	static int [][] totalPoints=null;
	static Node root = null;
	
	
	
	public void KDTreeSearch(int numOfPoints) {
	
		totalPoints = new int[numOfPoints][2];
		KDtree=new KDTree();
		CreateKDtree(numOfPoints);
		
		SearchOnKDtreeExistingPoints(numOfPoints);
		
		SearchOnKDtreeNonExistingPoints(numOfPoints);
	}
	
	public void PRQuadTreeSearch(int numOfPoints) {
		
		totalPoints = new int[numOfPoints][2];
		QuadTree=new PRQuadTree(0,0,N,N);
		createQuadTree(numOfPoints);
		
		SearchOnPRQuadTreeExistingPoints(numOfPoints);
		
		searchOnQuadTreeNonExistingPoints(numOfPoints);
	}
	
	public void CreateKDtree(int numOfPoints) {

		//KDtree KDTree= new KDtree();
		java.util.Random randomGenerator = new java.util.Random();
		int[] x = randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		int[] y=  randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		for(int i=0;i<x.length;i++) {
			int[] point=new int[2];
			point[0]=x[i];
			point[1]=y[i];
			//System.out.println(point.length);

			totalPoints[i]=point.clone();
			 root = KDtree.insert(root, point);
			}
		//Node node= new Node(point);
		
	           
	}
	public void SearchOnKDtreeExistingPoints(int numOfPoints) {
		
			
			java.util.Random randomGenerator = new java.util.Random();
			int existingPoint[]= randomGenerator.ints(0, numOfPoints).limit(numOfSearches).toArray();
		for (int j = 0; j < 100; j++) {
			
           KDtree.search(root, totalPoints[existingPoint[j]]);


            }

		System.out.println("Mean Depth for 100 searches of existing points is     : "+(float)KDTree.depthReached/100
				+" for :"+numOfPoints+" number of points ");
		System.out.println(" ");

		KDTree.depthReached=0;
		
	}
	
	public void SearchOnKDtreeNonExistingPoints(int numOfPoints) {
		
		java.util.Random randomGenerator = new java.util.Random();
		int[] x = randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		int[] y=  randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		
		for (int j=0;j<100;j++) {	
				int[] point=new int[2];
				point[0]=x[j];
				point[1]=y[j];
			KDtree.search(root,point);
			
		}
		
		System.out.println("Mean Depth for 100 searches of non existing points is : "+(float)KDTree.depthReached/100
				+" for :"+numOfPoints+" number of points ");
		System.out.println(" ");
		KDTree.depthReached=0;
        }
	
public void createQuadTree(int numOfPoints) {
		
		java.util.Random randomGenerator = new java.util.Random();
		int[] x = randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		int[] y=  randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		for(int i=0;i<x.length;i++) {
			int[] point=new int[2];
			point[0]=x[i];
			point[1]=y[i];
			//Point Point=new Point(point[0],point[1]);		
			//System.out.println(point.length);

			totalPoints[i]=point.clone();
			 QuadTree.insert(point[0],point[1]);
			}
		
		
	}
	public void SearchOnPRQuadTreeExistingPoints(int numOfPoints) {
		
		
		java.util.Random randomGenerator = new java.util.Random();
		int existingPoint[]= randomGenerator.ints(0, numOfPoints).limit(numOfSearches).toArray();
	for (int j = 0; j < 100; j++) {
		//Point point=new Point(totalPoints[existingPoint[j]][0],totalPoints[existingPoint[j]][1]);
		QuadTree.search(totalPoints[existingPoint[j]][0],totalPoints[existingPoint[j]][1]);
        }
	System.out.println("FOR EXISTING KEY");

	System.out.println("Mean Depth for 100 searches of existing points is     : "+(float)PRQuadTree.depthReached/100
			+" for :"+numOfPoints+" number of points ");

	PRQuadTree.depthReached=0;
	
}
	
	public void searchOnQuadTreeNonExistingPoints(int numOfPoints) {
		
		java.util.Random randomGenerator = new java.util.Random();
		int[] x = randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		int[] y=  randomGenerator.ints(0, N).limit(numOfPoints).toArray();
		
		for (int j=0;j<100;j++) {
			
			//for(int i=0;i<x.length;i++) {
				int[] point=new int[2];
				point[0]=x[j];
				point[1]=y[j];
				//Point Point=new Point(point[0],point[1]);	
				QuadTree.search(point[0],point[1]=y[j]);
			
		//}
		}
		System.out.println("FOR NON EXISTING KEY");
	
		System.out.println("Mean Depth for 100 searches of existing points is     : "+(float)PRQuadTree.depthReached/100
				+" for :"+numOfPoints+" number of points ");
	
		PRQuadTree.depthReached=0;
		
		
	}
	
	}
	
		
	
	
	
	
	
	
	
	
	
	


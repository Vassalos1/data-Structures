package main;

import methods.methods;

public class Main {

	static int NUMBER_OF_POINTS[] = {200, 500,1000,10000,30000 ,50000,70000 ,100000};
	//static int N=65536;
	final static int NUMBER_OF_SEARCHES=100;
	
	public static void main(String[] args) {
		long totalTestStartTimeNano, totalTestEndTimeNano;
		long totalTimeNano = 0;
		
		methods methods=new methods();
		System.out.println("RESULTS FOR K-D TREE");
		totalTestStartTimeNano = System.nanoTime();
		for (int i=0;i<8;i++) {
			methods.KDTreeSearch(NUMBER_OF_POINTS[i]);
			
		}
		
		totalTestEndTimeNano = System.nanoTime();

		totalTimeNano = totalTestEndTimeNano - totalTestStartTimeNano;
		System.out.println("total time for the k-d tree search is : "+ totalTimeNano/NUMBER_OF_SEARCHES);
		
		totalTimeNano=0;
		totalTestStartTimeNano = System.nanoTime();
		System.out.println("RESULTS FOR PR QUADTREE");
		for (int i=0;i<8;i++) {
			
			methods.PRQuadTreeSearch(NUMBER_OF_POINTS[i]);
			
		}
		totalTestEndTimeNano = System.nanoTime();
		totalTimeNano = totalTestEndTimeNano - totalTestStartTimeNano;
		System.out.println("total time for the k-d tree search is : "+ totalTimeNano/NUMBER_OF_SEARCHES);
	}

}

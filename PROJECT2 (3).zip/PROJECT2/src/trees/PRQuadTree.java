package trees;


import node.PRNode;
public class PRQuadTree {
	
	PRNode n;     // n is the root of the PR quadtree
	//int level;
	public static int depthReached=0;
	 
	public PRQuadTree(int xmin,int ymin,int xmax,int ymax) {

		n  = new PRNode(xmin,ymin,xmax,ymax);
		n.setLeaf(false);
		n.setX(-1);
		n.setY(-1);
	}
	
	/**
	 *  We devide the rectangle that contain the current node.
	 * @param n The node n to be devided
	 */
	public void devideRect(PRNode n)
	 {
		n.setNW(new PRNode(n.getXmin(), n.getYmin(), (n.getXmin()+n.getXmax())/2,(n.getYmin()+n.getYmax())/2 ));//done
		
		n.setSW(new PRNode( n.getXmin(), (n.getYmin()+n.getYmax())/2,(n.getXmin()+n.getXmax())/2,n.getYmax() ));//done
		
        n.setNE(new PRNode((n.getXmin()+n.getXmax())/2, n.getYmin(), n.getXmax(),(n.getYmin()+n.getYmax())/2 ));//done
        
		n.setSE(new PRNode((n.getXmin()+n.getXmax())/2, (n.getYmin()+n.getYmax())/2, n.getXmax(),n.getYmax() ));//done
		

	 }
	/*Wrapper method for inserting with only x,y parameters
	 * 
	 */
	public void insert(int x,int y) { 

		
       insert(n, x , y); 


	} 
	/**
	 * Recursion method for inserting nodes in the pr quad-tree
	 * First check if x,y values is in the boundary of the current node and the current node is a leaf
	 * if its true then insert the node,else devide the rectangle in SW,SE,NW,NE move the value of the node in the correct subtree  
	 * and move in the next recursionfor inserting
	 * 
	 * 
	 * @param node The node to be iserted
	 * @param x 
	 * @param y
	 */
	public void insert(PRNode node,int x,int y){
	   

	        if (inBoundary(x,y,node)==true && leaf(node)==true) {
	        	node.setX(x);
	        	node.setY(y);
	        	node.setLeaf(false);
	        	return ;  
	        }
	        else 
			{
	        	if(node.isDivided()==false && inBoundary(x,y,node)==true) {
	        		this.devideRect(node);
	        		node.setDivided(true);
	        		
	        		if(node.getX() !=-1 && node.getY()!=-1 && leaf(node)==false) {
	        		 if(inBoundary(node.getX(),node.getY(),node.getNE()))
	     	        	{
	        			node.getNE().x=node.getX();
	        			node.getNE().y=node.getY();
	     	        	node.setX(-1);
	    	        	node.setY(-1);
	    	        	node.getNE().leaf=false;
	     	        	}
	     	        
	     	        else if(inBoundary(node.getX(),node.getY(),node.getNW()))
	     	        	{
	     	        	
	        			node.getNW().x=node.getX();
	        			node.getNW().y=node.getY();
	     	        	node.setX(-1);
	    	        	node.setY(-1);
	    	        	node.getNW().leaf=false;
	     	        	}
	     			
	     	        else if(inBoundary(node.getX(),node.getY(),node.getSW()))
	     	        	{
	        			node.getSW().x=node.getX();
	        			node.getSW().y=node.getY();
	     	        	node.setX(-1);
	    	        	node.setY(-1);
	    	        	node.getSW().leaf=false;
	     	        	}
	     			
	     	        else if(inBoundary(node.x,node.y,node.getSE()))
	     	        	{
	     	        	
	        			node.getSE().x=node.getX();
	        			node.getSE().y=node.getY();
	     	        	node.setX(-1);
	    	        	node.setY(-1);
	    	        	node.getSE().leaf=false;
	     	        	}
	        		}
	        	}
			}

	        
	        if(inBoundary(x,y,node.getNE()))
	        	insert(node.getNE(),x,y);
	        
	        else if(inBoundary(x,y,node.getNW()))
	        	insert(node.getNW(),x,y);
			
	        else if(inBoundary(x,y,node.getSE()))
	        	insert(node.getSE(),x,y);
			
	        else if(inBoundary(x,y,node.getSW()))
	        	insert(node.getSW(),x,y);
			
			return ;

	}
	
	
	public boolean isLeaf(PRNode node)
	{
		if((node.getSW() == null) && (node.getNE() == null) && (node.getNW() == null )&& (node.getSE() == null) )
			return true;
		return false;
	}
	
	public PRNode search(int x,int y) { 

		//level=0;
		PRNode ni =  search(n, x , y); 
		return ni;
		
	       
	    }
	/**
	 * Search for x,y values
	 * If x,y values exist then return the current node 
	 * else return null
	 */
	public PRNode search(PRNode node,int x,int y) 
	{ 
		
		if(node==null)
			 return null;
		
		
		 if (inBoundary(x,y,node)==true) {
	        	if(node.getX()==x && node.getY()==y) {
	        	
	        	return node;  
	        	}
	        	
	        }
		 else
			 return null;
		 
		 
	        if(node.getNE()!= null && inBoundary(x,y,node.getNE()))
	        {
	        	depthReached++;
	        //	level++;
	        	return search(node.getNE(),x,y);
	        }
	        
	        else if(node.getNW()!= null && inBoundary(x,y,node.getNW()))
	        {
	        	depthReached++;

	        //	level++;
	        	return search(node.getNW(),x,y);
	        }
			
	        else if(node.getSE()!= null && inBoundary(x,y,node.getSE()))
	        {
	        	depthReached++;

	        //	level++;
	        	return search(node.getSE(),x,y);
	        }
			
	        else if(node.getSW()!= null &&inBoundary(x,y,node.getSW()))
	        {
	        	depthReached++;

	        //	level++;
	        	return search(node.getSW(),x,y);
	        }
	        else {
	        	depthReached++;
	        	return null;
	        }
	        			

	}

	/**
	 * Method for check if x,y values can be in the current node
	 *
	 */
	public boolean inBoundary(int x,int y,PRNode n ) 
	{ 
	    return (x >= n.getXmin() && 
	        x <= n.getXmax() && 
	        y >= n.getYmin() && 
	        y <= n.getYmax()); 
	}

	public PRNode getN() {
		return n;
	}

	public void setN(PRNode n) {
		this.n = n;
	}
	
	public boolean leaf(PRNode node)
	{
		if(node.isLeaf())
			return true;
			return false;
	}
	
	
}


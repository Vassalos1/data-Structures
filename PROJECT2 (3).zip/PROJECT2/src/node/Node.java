package node;

public class Node {
	
	public Node(int[] arr)
    {
        this.point = arr;
        this.left = this.right = null;
    }
    public Node() {
		// TODO Auto-generated constructor stub
	}
	public int[] getPoint() {
		return point;
	}

	public void setPoint(int[] point) {
		this.point = point;
	}

	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node right) {
		this.right = right;
	}

	int[] point;
    Node left, right;
 
   
}
package node;


public class PRNode {
private PRNode internal;

public int x;
public int y;
int Xmin;
int Xmax;
int Ymin;
int Ymax;
PRNode NW;
PRNode NE;
PRNode SW;
PRNode SE;
public boolean leaf;
private boolean divided;

public PRNode(int xmin,int ymin,int xmax,int ymax) //interanl node
{ 
	this.Xmin = xmin;
	this.Xmax = xmax;
	this.Ymin = ymin;
	this.Ymax = ymax;
    this.NW=null;
    this.NE=null;
    this.SW=null;
    this.SE=null;
    leaf=true;
    this.setDivided(false);

}


public boolean isLeaf() {
	return leaf;
}

public void setLeaf(boolean leaf) {
	this.leaf = leaf;
}



public PRNode getInternal() {
	return internal;
}

public void setInternal(PRNode internal) {
	this.internal = internal;
}

public int getX() {
	return x;
}

public void setX(int x) {	
	this.x = x;
}

public int getY() {
	return y;
}

public void setY(int y) {
	this.y = y;
}

public int getXmin() {
	return Xmin;
}

public void setXmin(int xmin) {
	Xmin = xmin;
}

public int getXmax() {
	return Xmax;
}

public void setXmax(int xmax) {
	Xmax = xmax;
}

public int getYmin() {
	return Ymin;
}

public void setYmin(int ymin) {
	Ymin = ymin;
}

public int getYmax() {
	return Ymax;
}

public void setYmax(int ymax) {
	Ymax = ymax;
}

public PRNode getNW() {
	return NW;
}

public void setNW(PRNode nW) {
	NW = nW;
}

public PRNode getNE() {
	return NE;
}

public void setNE(PRNode nE) {
	NE = nE;
}

public PRNode getSW() {
	return SW;
}

public void setSW(PRNode sW) {
	SW = sW;
}

public PRNode getSE() {
	return SE;
}

public void setSE(PRNode sE) {
	SE = sE;
}
public boolean isDivided() {
	return divided;
}
public void setDivided(boolean divided) {
	this.divided = divided;
} 



}